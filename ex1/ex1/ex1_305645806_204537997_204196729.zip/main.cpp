
#include <string>
#include "BattleshipGameManager.h"
#include <fstream>


#define DIRLIST_TMP_FILE_PATH "~tmp_dir.txt"

bool isValidDir(const std::string& path)
{
	std::stringstream cdCommandString;
	cdCommandString << "cd " << path << " 1> nul 2> nul" << std::endl;
	int commandRes = system(cdCommandString.str().c_str());
	if (commandRes == 0)
		return true;
	else
		return  false;
}


bool isStringEndsWith(const std::string& str, const std::string& suffix) {
	if (suffix.size() > str.size()) return false;
	return std::equal(str.begin() + str.size() - suffix.size(), str.end(), suffix.begin());
}

//check the dir list in ~tmp_dir.txt, check if the 3 files exists, prints relevant erros if needed, and then delete the die list file
bool isAllGameFilesExists(const std::string& dir_path, std::string& boardPath, std::string& attackFilePath_a, std::string& attackFilePath_b)
{
	bool isAttackFileExistsA = false, isAttackFileExistsB = false, isBoardExists = false;
	std::string currentFilename;
	std::ifstream dirListFile(DIRLIST_TMP_FILE_PATH);

	if (dirListFile.is_open())
	{
		while ((getline(dirListFile, currentFilename)) && !(isAttackFileExistsA && isAttackFileExistsB && isBoardExists)) //we take the first file for every extension. todo: check the getline if necesseray
		{
			if (!isBoardExists && isStringEndsWith(currentFilename, ".sboard"))
			{
				boardPath = dir_path.empty() ? currentFilename : dir_path + "\\" + currentFilename;
				isBoardExists = true;
			}
			else if (!isAttackFileExistsA && isStringEndsWith(currentFilename, ".attack-a"))
			{
				attackFilePath_a = dir_path.empty() ? currentFilename : dir_path + "\\" + currentFilename;
				isAttackFileExistsA = true;
			}
			else if (!isAttackFileExistsB && isStringEndsWith(currentFilename, ".attack-b"))
			{
				attackFilePath_b = dir_path.empty() ? currentFilename : dir_path + "\\" + currentFilename;
				isAttackFileExistsB = true;
			}
		}
		if (!dirListFile.eof() && !(isAttackFileExistsA && isAttackFileExistsB && isBoardExists)) {//we have problem in reading tmpdirfile - exit game!
			std::cout << "Error reading temp dirList file in "<< DIRLIST_TMP_FILE_PATH <<" , Exit from Game."<< std::endl;
			return false;
		}
		dirListFile.close();
	}

	else {
		std::cout << "Unable to open temp dirList file in " << DIRLIST_TMP_FILE_PATH << " , Exit from Game." << std::endl;
		return false;
	}

	//print relevant error messages

	if (isBoardExists && isAttackFileExistsA && isAttackFileExistsB) {
		return true;
	}
	else {
		if (!isBoardExists)
		{
			std::cout << "Missing board file (*.sboard) looking in path: " << dir_path << std::endl;
		}
		if (!isAttackFileExistsA)
		{
			std::cout << "Missing attack file for player A (*.attack-a) looking in path: " << dir_path << std::endl;
		}
		if (!isAttackFileExistsB)
		{
			std::cout << "Missing attack file for player B (*.attack-b) looking in path: " << dir_path << std::endl;
		}
		return false;
	}

}

bool checkGamefiles(const std::string& dir_path, std::string& boardPath, std::string& attackFilePath_a, std::string& attackFilePath_b) {
	
	if (!isValidDir(dir_path)) {
		std::cout << "Wrong path: " << dir_path << std::endl;
		return false;
	}

	//writes only filenames (without directory names) in dir_path directory 
	//to ~tmp_dir.txt new file in working directory
	
	std::stringstream dirCmd;
	dirCmd << "dir \"" << dir_path << "\" /b /a-d" << ">\""<<DIRLIST_TMP_FILE_PATH<<"\"" << " 2> nul";
	system(dirCmd.str().c_str());


	if (!isAllGameFilesExists(dir_path, boardPath, attackFilePath_a, attackFilePath_b))
	{
		remove(DIRLIST_TMP_FILE_PATH);
		return false;
	}

	remove(DIRLIST_TMP_FILE_PATH);
	return true;
}



int main(int argc, char* argv[])
{

	//_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
	std::string dir_path = "", boardPath="", attackFilePath_a="", attackFilePath_b="";

	bool isGameSuccessfullyCreated = false;

	if (argc > 1)
		dir_path = argv[1];

	if(!checkGamefiles(dir_path, boardPath, attackFilePath_a, attackFilePath_b)){
		//todo: problem with game files, exiting..
		std::cout << "board file in :" << boardPath << std::endl;
		std::cout << "ATTACK A file in :" << attackFilePath_a << std::endl;
		std::cout << "ATTACK B file in :" << attackFilePath_b << std::endl;
		std::cin.get();
		return -1;
	}
	std::cout << "board file in :" << boardPath << std::endl;
	std::cout << "ATTACK A file in :" << attackFilePath_a << std::endl;
	std::cout << "ATTACK B file in :" << attackFilePath_b << std::endl;

	BattleshipGameManager Game(boardPath, attackFilePath_a, attackFilePath_b, isGameSuccessfullyCreated);

	if (!isGameSuccessfullyCreated) {
		std::cin.get();
		return -1;
	}

	Game.Run();

	
	std::cin.get();
	return 0;
}

